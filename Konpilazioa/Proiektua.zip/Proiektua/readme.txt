Praktika abiarazteko E07 karpetan sartu, izan daiteke cd E07 egin behar izatea, irekitzen den lekuaren arabera. 

Ondoren terminalean 'make' eginez 'test' karpetan dauden proba kasu guztiak exekutatuko dira. 

Gorka Puente & Oier Álvarez
