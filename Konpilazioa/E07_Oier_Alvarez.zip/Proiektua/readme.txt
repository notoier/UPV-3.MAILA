Praktika abiarazteko E07 karpetan sartu, izan daiteke cd E07 egin behar izatea, irekitzen den lekuaren arabera. 

Ondoren terminalean 'make' eginez 'test' karpetan dauden proba kasu guztiak exekutatuko dira. 


---------------------------------------------------- BESTELAKO INFORMAZIOA ------------------------------------------------------

Ahalik eta gehiena zuzentzen saiatu naiz, baina denbora dela eta gauza batzuk ezin izan ditut 'konpondu' (zuhaitz gehiago egitea, adibidez).

Bestetik, lehentasunak txarto zeudela eta zuhaitzean lortutako emaitzarekin bat ez zetorrela ipini zenidan, 
baina konprobatu dut, eta eskuz egitean eta konpilatzean emaitza bera lortu dut, beraz hori ez dut ia ikutu. 

---------------------------------------------------------------------------------------------------------------------------------

Gorka Puente & Oier Álvarez
